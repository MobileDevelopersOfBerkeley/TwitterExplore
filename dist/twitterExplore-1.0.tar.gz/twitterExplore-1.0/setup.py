from setuptools import setup

setup(
    name='twitterExplore',    # This is the name of your PyPI-package.
    version='1.0',                          # Update the version number for new releases
    scripts=['python api_call.py']                  # The name of your scipt, and also the command you'll be using for calling it
)